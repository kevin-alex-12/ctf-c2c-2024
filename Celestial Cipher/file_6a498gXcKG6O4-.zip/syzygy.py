from Crypto.Util.number import *
from flag import flag
import gmpy2

def syzygy(p):
    return int(float(p) - (float(p) / float(3**(3*3*3)) + 3))

def generatePrime():
    p = getPrime(81)
    q = gmpy2.next_prime(syzygy(p))
    return p, q

def encrypt(m, n):
    m = bytes_to_long(m.encode())
    assert m < n
    return pow(m, 65537, n)

flag = flag()
p, q = generatePrime()
assert p != q
n = p * q
c = encrypt(flag, n)
print("n =", n)
print("c =", c)
